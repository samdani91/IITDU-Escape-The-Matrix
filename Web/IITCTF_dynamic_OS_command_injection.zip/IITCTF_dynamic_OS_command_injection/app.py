from flask import Flask, request, render_template_string
import subprocess
import os

app = Flask(__name__)

PAGE = """
<!doctype html>
<html>
<head><title>IITCTF - OS Command Injection</title></head>
<body>
<h1>Product Stock Checker</h1>
<form action="/stock" method="get">
  <label>Product ID:</label>
  <input name="productId" value="{{ value }}">
  <button type="submit">Check stock</button>
</form>
{% if output is not none %}
<h2>Result</h2>
<pre>{{ output }}</pre>
{% endif %}
</body>
</html>
"""

@app.get("/")
def index():
    return render_template_string(PAGE, value="", output=None)

@app.get("/stock")
def stock():
    value = request.args.get("productId", "")

    # INTENTIONALLY VULNERABLE:
    # Attacker-controlled input is concatenated into a shell command.
    command = f"printf 'Stock available for product {value}\\n'"

    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=5
        )
        output = result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        output = "Command timed out."

    return render_template_string(PAGE, value=value, output=output)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
