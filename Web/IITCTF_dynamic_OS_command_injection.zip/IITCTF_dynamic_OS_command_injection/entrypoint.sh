#!/bin/sh
set -eu

# Generate a fresh random flag for every new container instance.
# 24 hex characters = 96 bits of randomness.
RANDOM_FLAG="$(python - <<'PY'
import secrets
print(secrets.token_hex(12))
PY
)"

printf 'IITCTF{%s}\n' "$RANDOM_FLAG" > /flag.txt
chmod 0400 /flag.txt
chown ctfuser:ctfuser /flag.txt

exec "$@"
